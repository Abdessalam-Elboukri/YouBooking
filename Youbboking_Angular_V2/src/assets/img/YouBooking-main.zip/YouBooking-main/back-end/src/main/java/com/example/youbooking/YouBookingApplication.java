package com.example.youbooking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class YouBookingApplication {

    public static void main(String[] args) {
        SpringApplication.run(YouBookingApplication.class, args);
    }

}
