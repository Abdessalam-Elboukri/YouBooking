package com.example.youbooking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class YouBookingApplicationTests {

    @Test
    void contextLoads() {
    }

}
