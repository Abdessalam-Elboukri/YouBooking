package com.example.youbooking.entities;

public enum StatusChamber {
    Disponible,
    Indisponible
}
