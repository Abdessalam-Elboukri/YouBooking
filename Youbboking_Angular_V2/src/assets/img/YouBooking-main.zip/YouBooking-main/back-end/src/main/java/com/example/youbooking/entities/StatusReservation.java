package com.example.youbooking.entities;

public enum StatusReservation {
    Encours,
    Accepte,
    Refuse
}
