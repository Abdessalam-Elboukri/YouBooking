package com.example.youbooking.entities;

public enum Status {
    Active,
    Desactive
}
