export class Login {
  id?:number;
  email:string;
  password:string;


  constructor() {
    this.email = "";
    this.password ="";
  }
}
