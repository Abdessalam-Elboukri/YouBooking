export class Reservation {
}
