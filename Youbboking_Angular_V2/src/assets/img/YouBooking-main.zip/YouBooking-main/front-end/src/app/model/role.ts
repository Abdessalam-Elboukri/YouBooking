export class Role { 
  id?:number;
  nom:string;

  constructor() {
    this.nom = "";
  }
}
