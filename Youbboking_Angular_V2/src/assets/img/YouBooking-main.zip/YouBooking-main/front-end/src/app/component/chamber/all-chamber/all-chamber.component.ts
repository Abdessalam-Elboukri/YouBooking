import { Component } from '@angular/core';

@Component({
  selector: 'app-all-chamber',
  templateUrl: './all-chamber.component.html',
  styleUrls: ['./all-chamber.component.css']
})
export class AllChamberComponent {

}
